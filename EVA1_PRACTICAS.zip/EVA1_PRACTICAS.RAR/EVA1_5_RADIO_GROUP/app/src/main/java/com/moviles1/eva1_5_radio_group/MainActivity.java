package com.moviles1.eva1_5_radio_group;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
    private RadioGroup rgroup1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rgroup1 = findViewById(R.id.radioGroup1);
        rgroup1.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        //i es el id del radiobutton seleccionado
        RadioButton rb = findViewById(i);
        String mensaje = (String) rb.getText();
        Toast.makeText(this,mensaje,Toast.LENGTH_SHORT).show();
    }
}
